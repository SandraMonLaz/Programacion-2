#pragma once

#include "System.h"

class CollisionSystem: public System {
public:
	CollisionSystem();

	void update() override;

};

