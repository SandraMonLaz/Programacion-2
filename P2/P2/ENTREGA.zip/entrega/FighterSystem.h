#pragma once
#include "System.h"
#include "Entity.h"
#include "Transform.h"
#include "Health.h"
#include "ImageComponent.h"
#include "Manager.h"

class FighterSystem : public System
{
public:
	FighterSystem() : System(ecs::_sys_Fighter) {};
	~FighterSystem() {};
	// Pone el caza en el centro con velocidad 0 y rotaci�n 0. 
	void onCollisionWithAsteroid(Entity* a);
	// Crea la entidad del caza, a�ade sus componentes (Transform, Health, etc.)
	// y la asocia con el handler _hndlr_Fighter.
	void init() override;
	void update() override;
private:
	const double THRUST = 0.5;
	const double ANGLE = 10.0;
	double maxVel = 5.5;
	double drag_ = 0.45;
};

